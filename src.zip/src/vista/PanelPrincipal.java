package vista;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class PanelPrincipal JFrame {

    private JPanel contentPane;
    private JTable tableIncidentes;
    private int mouseX, mouseY; // Variables para arrastrar la ventana

    /**
     * Constructor de la Ventana del Coordinador
     */
    public CPanelPrincipal) {
        
        // 1. CONFIGURACIÓN DE LA VENTANA (1000x700)
        setUndecorated(true); // Oculta la barra de título nativa
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1000, 700));
        setResizable(false);
        
        // 2. CONFIGURACIÓN DEL CONTENT PANE con ABSOLUTE LAYOUT
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null); 
        pack(); // Ajusta el tamaño de la ventana
        setLocationRelativeTo(null); // Centra la ventana al inicio

        // -------------------------------------------------------------------
        // A. BARRA DE TÍTULO CUSTOM (X: 0, Y: 0, Ancho: 1000, Alto: 40)
        // -------------------------------------------------------------------
        JPanel panelTitleBar = new JPanel();
        panelTitleBar.setBackground(new Color(30, 60, 90)); 
        panelTitleBar.setBounds(0, 0, 1000, 40);
        panelTitleBar.setLayout(null);
        contentPane.add(panelTitleBar);
        
        // (i) Logo/Título
        JLabel lblAppTitle = new JLabel("🛡️ GESTOR DE EMERGENCIAS COMUNITARIAS");
        lblAppTitle.setForeground(Color.WHITE);
        lblAppTitle.setFont(new Font("Arial", Font.BOLD, 14));
        lblAppTitle.setBounds(10, 5, 400, 30);
        panelTitleBar.add(lblAppTitle);
        
        // (ii) Botones de Control (Cerrar 'X' y Minimizar '_')
        JButton btnClose = new JButton("X");
        btnClose.setForeground(Color.WHITE);
        btnClose.setBackground(new Color(255, 100, 100));
        btnClose.setFocusPainted(false);
        btnClose.setBounds(960, 0, 40, 40);
        btnClose.addActionListener(e -> System.exit(0)); 
        panelTitleBar.add(btnClose);

        JButton btnMinimize = new JButton("_");
        btnMinimize.setForeground(Color.WHITE);
        btnMinimize.setBackground(new Color(50, 80, 120));
        btnMinimize.setFocusPainted(false);
        btnMinimize.setBounds(920, 0, 40, 40);
        btnMinimize.addActionListener(e -> setExtendedState(JFrame.ICONIFIED)); 
        panelTitleBar.add(btnMinimize);
        
        // (iii) Lógica para Mover la Ventana (Arrastrar)
        panelTitleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                mouseX = e.getX();
                mouseY = e.getY();
            }
        });
        panelTitleBar.addMouseMotionListener(new MouseAdapter() {
            public void mouseDragged(MouseEvent e) {
                setLocation(e.getXOnScreen() - mouseX, e.getYOnScreen() - mouseY);
            }
        });

        // -------------------------------------------------------------------
        // B. PANEL LATERAL DE NAVEGACIÓN (X: 0, Y: 40, Ancho: 200, Alto: 620)
        // -------------------------------------------------------------------
        JPanel panelNavegacion = new JPanel();
        panelNavegacion.setBackground(new Color(240, 240, 240)); 
        panelNavegacion.setBounds(0, 40, 200, 620); 
        panelNavegacion.setLayout(null);
        contentPane.add(panelNavegacion);
        
        // Botones de Navegación (6 botones, espaciado de 10px, Alto: 40px)
        int yPos = 20; 

        JButton btnDashboard = new JButton("Dashboard");
        btnDashboard.setHorizontalAlignment(SwingConstants.LEFT);
        btnDashboard.setBounds(10, yPos, 180, 40); 
        panelNavegacion.add(btnDashboard);

        yPos += 50; 

        JButton btnIncidentes = new JButton("🚨 Incidentes Activos");
        btnIncidentes.setHorizontalAlignment(SwingConstants.LEFT);
        btnIncidentes.setBackground(new Color(200, 220, 255));
        btnIncidentes.setBounds(10, yPos, 180, 40);
        panelNavegacion.add(btnIncidentes);

        yPos += 50;

        JButton btnInventario = new JButton("📦 Inventario Suministros");
        btnInventario.setHorizontalAlignment(SwingConstants.LEFT);
        btnInventario.setBounds(10, yPos, 180, 40);
        panelNavegacion.add(btnInventario);

        yPos += 50;

        JButton btnBrigadistas = new JButton("🛡️ Brigadistas");
        btnBrigadistas.setHorizontalAlignment(SwingConstants.LEFT);
        btnBrigadistas.setBounds(10, yPos, 180, 40);
        panelNavegacion.add(btnBrigadistas);

        yPos += 50;

        JButton btnGuias = new JButton("📚 Guías P. Auxilios");
        btnGuias.setHorizontalAlignment(SwingConstants.LEFT);
        btnGuias.setBounds(10, yPos, 180, 40);
        panelNavegacion.add(btnGuias);

        yPos += 50;

        JButton btnReportes = new JButton("📊 Reportes");
        btnReportes.setHorizontalAlignment(SwingConstants.LEFT);
        btnReportes.setBounds(10, yPos, 180, 40);
        panelNavegacion.add(btnReportes);

        // -------------------------------------------------------------------
        // C. PANEL PRINCIPAL DE CONTENIDO (X: 200, Y: 40, Ancho: 800, Alto: 620)
        // -------------------------------------------------------------------
        JPanel panelContenido = new JPanel();
        panelContenido.setBackground(Color.WHITE);
        panelContenido.setBounds(200, 40, 800, 620);
        panelContenido.setLayout(null); 
        contentPane.add(panelContenido);
        
        // --- (i) Panel Superior de Filtros y Acciones ---
        JPanel panelFiltros = new JPanel();
        panelFiltros.setBounds(0, 0, 800, 50); 
        panelFiltros.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 10, 10));
        panelContenido.add(panelFiltros);

        panelFiltros.add(new JLabel("Tipo:"));
        JComboBox<String> comboTipo = new JComboBox<>(new String[] {"Todos", "Médico", "Incendio"});
        panelFiltros.add(comboTipo);
        panelFiltros.add(new JLabel("Estado:"));
        JComboBox<String> comboEstado = new JComboBox<>(new String[] {"Todos", "Nuevo", "En Curso"});
        panelFiltros.add(comboEstado);
        panelFiltros.add(new JButton("Reportar Nuevo"));
        panelFiltros.add(new JButton("Ver Mapa General"));


        // --- (ii) Tabla de Incidentes Activos ---
        JScrollPane scrollPaneIncidentes = new JScrollPane();
        scrollPaneIncidentes.setBounds(10, 60, 520, 550); 
        panelContenido.add(scrollPaneIncidentes);

        tableIncidentes = new JTable(
            new DefaultTableModel(
                new Object[][] {
                    {"001", "ALTA", "Incendio", "NUEVO", "Av. Roca 456"},
                    {"002", "MEDIA", "Médico", "EN CURSO", "Calle Falsa 123"},
                    {"003", "BAJA", "Inundación", "NUEVO", "Puente Viejo"},
                    {"004", "MEDIA", "Accidente", "EN CURSO", "Ruta 3 Km 10"},
                }, 
                new String[] {"ID", "Prioridad", "Tipo", "Estado", "Ubicación"}
            )
        );
        scrollPaneIncidentes.setViewportView(tableIncidentes);


        // --- (iii) Panel de Brigadistas Disponibles ---
        JPanel panelBrigadistas = new JPanel();
        panelBrigadistas.setBounds(540, 60, 250, 550);
        panelBrigadistas.setLayout(null); 
        panelBrigadistas.setBorder(javax.swing.BorderFactory.createTitledBorder("Asignación Rápida"));
        panelContenido.add(panelBrigadistas);

        JScrollPane scrollPaneBrigadistas = new JScrollPane();
        scrollPaneBrigadistas.setBounds(10, 20, 230, 470);
        panelBrigadistas.add(scrollPaneBrigadistas);

        JList<String> listBrigadistas = new JList<>(new String[] {"✅ Juan Pérez (Libre)", "❌ María Gómez (Ocupada)", "✅ Pedro García (Libre)"});
        scrollPaneBrigadistas.setViewportView(listBrigadistas);

        JButton btnAsignar = new JButton("ASIGNAR BRIGADISTA");
        btnAsignar.setFont(new Font("Arial", Font.BOLD, 12));
        btnAsignar.setBounds(10, 500, 230, 40);
        panelBrigadistas.add(btnAsignar);


        // -------------------------------------------------------------------
        // D. FOOTER DE ALERTAS (X: 0, Y: 660, Ancho: 1000, Alto: 40)
        // -------------------------------------------------------------------
        JPanel panelFooter = new JPanel();
        panelFooter.setBackground(new Color(50, 50, 50)); 
        panelFooter.setBounds(0, 660, 1000, 40); 
        panelFooter.setLayout(null);
        contentPane.add(panelFooter);

        // Etiqueta de Conexión
        JLabel lblConexion = new JLabel("Conexión: OK");
        lblConexion.setForeground(Color.GREEN);
        lblConexion.setBounds(10, 5, 150, 25);
        panelFooter.add(lblConexion);

        // Etiqueta de Actualización
        JLabel lblActualizacion = new JLabel("Última Actualización: 7:55 AM");
        lblActualizacion.setForeground(Color.WHITE);
        lblActualizacion.setBounds(400, 5, 200, 25);
        panelFooter.add(lblActualizacion);

        // Etiqueta de Alertas Críticas
        JLabel lblAlertas = new JLabel("⚠️ ALERTAS: 2 Suministros Bajos");
        lblAlertas.setForeground(Color.YELLOW);
        lblAlertas.setFont(new Font("Arial", Font.BOLD, 12));
        lblAlertas.setBounds(780, 5, 250, 25);
        panelFooter.add(lblAlertas);
    }

    /**
     * Main method to launch the application.
     */
    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> {
            try {
                CPanelPrincipalframe = new CPanelPrincipal);
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}